n = 3
for i in range(n):
    print("*" * (n-i)) # Prints * n-i times
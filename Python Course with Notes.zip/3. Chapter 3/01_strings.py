# b = "Harry's" # --> Use this if you have single quotes in your strings
# b = 'Harry"s'
b = '''Harry"s and 
       Harry's'''
print(b)
# print(type(b))

print("Hello", end=" ")
print("How", end=" ")
print("are", end=" ")
print("you?", end=" ")
import m06_file1
m06_file1.greet("Harry")